import { Service, Project, TeamMember } from '../types';

export const services: Service[] = [
  {
    id: '1',
    title: 'Web Development',
    description: 'Custom websites and web applications built with modern technologies and best practices.',
    icon: 'Code',
    features: ['Responsive Design', 'Performance Optimization', 'SEO Ready', 'Modern Frameworks']
  },
  {
    id: '2',
    title: 'Digital Marketing',
    description: 'Comprehensive digital marketing strategies to grow your online presence and reach.',
    icon: 'TrendingUp',
    features: ['Social Media Marketing', 'Content Strategy', 'PPC Campaigns', 'Analytics & Reporting']
  },
  {
    id: '3',
    title: 'Brand Identity',
    description: 'Complete brand identity design including logos, guidelines, and visual assets.',
    icon: 'Palette',
    features: ['Logo Design', 'Brand Guidelines', 'Visual Identity', 'Print Materials']
  },
  {
    id: '4',
    title: 'UI/UX Design',
    description: 'User-centered design solutions that create engaging and intuitive digital experiences.',
    icon: 'Figma',
    features: ['User Research', 'Wireframing', 'Prototyping', 'Usability Testing']
  }
];

export const projects: Project[] = [
  {
    id: '1',
    title: 'E-commerce Platform',
    description: 'Modern e-commerce solution with advanced features and seamless user experience.',
    image: 'https://images.pexels.com/photos/230544/pexels-photo-230544.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'Web Development',
    technologies: ['React', 'Node.js', 'MongoDB', 'Stripe'],
    link: '#'
  },
  {
    id: '2',
    title: 'Brand Redesign',
    description: 'Complete brand identity redesign for a tech startup including logo and guidelines.',
    image: 'https://images.pexels.com/photos/196644/pexels-photo-196644.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'Branding',
    technologies: ['Figma', 'Illustrator', 'Photoshop'],
    link: '#'
  },
  {
    id: '3',
    title: 'Mobile App Design',
    description: 'Intuitive mobile app design for a fitness tracking application with modern UI.',
    image: 'https://images.pexels.com/photos/147413/twitter-facebook-together-exchange-of-information-147413.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'UI/UX Design',
    technologies: ['Figma', 'Principle', 'After Effects'],
    link: '#'
  },
  {
    id: '4',
    title: 'Marketing Campaign',
    description: 'Comprehensive digital marketing campaign that increased client revenue by 300%.',
    image: 'https://images.pexels.com/photos/265087/pexels-photo-265087.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'Marketing',
    technologies: ['Google Ads', 'Facebook Ads', 'Analytics'],
    link: '#'
  },
  {
    id: '5',
    title: 'SaaS Dashboard',
    description: 'Clean and functional dashboard design for a project management SaaS platform.',
    image: 'https://images.pexels.com/photos/590016/pexels-photo-590016.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'Web Development',
    technologies: ['Vue.js', 'D3.js', 'Tailwind CSS'],
    link: '#'
  },
  {
    id: '6',
    title: 'Restaurant Website',
    description: 'Beautiful restaurant website with online ordering and reservation system.',
    image: 'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'Web Development',
    technologies: ['WordPress', 'WooCommerce', 'Custom PHP'],
    link: '#'
  }
];

export const teamMembers: TeamMember[] = [
  {
    id: '1',
    name: 'Sarah Johnson',
    role: 'Creative Director',
    image: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=400',
    bio: 'With over 8 years of experience in creative direction, Sarah leads our design team with passion and innovation.',
    social: {
      linkedin: '#',
      twitter: '#'
    }
  },
  {
    id: '2',
    name: 'Michael Chen',
    role: 'Lead Developer',
    image: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=400',
    bio: 'Michael is a full-stack developer with expertise in modern web technologies and scalable architecture.',
    social: {
      linkedin: '#',
      github: '#'
    }
  },
  {
    id: '3',
    name: 'Emily Rodriguez',
    role: 'Marketing Strategist',
    image: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=400',
    bio: 'Emily specializes in digital marketing strategies that drive growth and engagement for our clients.',
    social: {
      linkedin: '#',
      twitter: '#'
    }
  },
  {
    id: '4',
    name: 'David Kim',
    role: 'UX Designer',
    image: 'https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=400',
    bio: 'David creates user-centered designs that combine functionality with beautiful aesthetics.',
    social: {
      linkedin: '#',
      twitter: '#'
    }
  }
];